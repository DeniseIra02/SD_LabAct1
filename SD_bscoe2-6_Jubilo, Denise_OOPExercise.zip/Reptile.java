public abstract class Reptile extends Zoo_Animals{
    public Reptile(String animal_name, int animal_age, String animal_gender){
        super(animal_name, animal_age, animal_gender);
    }
}