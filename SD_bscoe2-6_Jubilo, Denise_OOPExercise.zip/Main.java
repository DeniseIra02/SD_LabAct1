public class Main{
    public static void main(String[] args){
        Lion anml_lion = new Lion("Kiara", 4, "Female");
        anml_lion.displayInfo();
        anml_lion.speak();
  
        Elephant elephant = new Elephant("Murati", 9, "Male");
        elephant.displayInfo();
        elephant.speak();

        Dog anml_dog = new Dog("Primo", 2, "Male");
        anml_dog.displayInfo();
        anml_dog.speak();

        PolarBear anml_pbear = new PolarBear("Grizz", 7, "Male");
        anml_pbear.displayInfo();
        anml_pbear.speak();
  
        Snake anml_snake = new Snake("Medusa", 4, "Female");
        anml_snake.displayInfo();
        anml_snake.speak();
  
        Lizard anml_lizard = new Lizard("Puff", 3, "Female");
        anml_lizard.displayInfo();
        anml_lizard.speak();

        Tortoise anml_tortoise = new Tortoise("Mack", 5, "Male");
        anml_tortoise.displayInfo();
        anml_tortoise.speak();

        Crocodile anml_crocodile = new Crocodile("Mack", 5, "Male");
        anml_crocodile.displayInfo();
        anml_crocodile.speak();
  
        Eagle anml_eagle = new Eagle("Dash", 5, "Male");
        anml_eagle.displayInfo();
        anml_eagle.speak();

        Parrot anml_parrot = new Parrot("Ruby", 3, "Female");
        anml_parrot.displayInfo();
        anml_parrot.speak();

        Owl anml_owl = new Owl("Catcher", 2, "Female");
        anml_owl.displayInfo();
        anml_owl.speak();
  
        Woodpecker anml_woodpecker = new Woodpecker("Downy", 1, "Female");
        anml_woodpecker.displayInfo();
        anml_woodpecker.speak();
    }
}